
export interface Usuario{
    Id : number; 
    Nome : string;
    RG : string;
    CPF : string;
    Email : string;
    Senha : string;
    Indicador : number;
}