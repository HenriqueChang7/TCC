import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms'
import { RouterModule } from '@angular/router';

import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { InputMaskModule } from 'primeng/inputmask';
import { UsuarioLoginComponent } from './Usuario-Login/Usuario-Login.component';
import { UsuarioCadastroComponent } from './Usuario-Cadastro/Usuario-Cadastro.component';
import { PerguntaRespostaModule } from '../PerguntaRespostas/perguntaResposta.module';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';


import { TableModule } from 'primeng/table';
import { AccordionModule } from 'primeng/accordion';
import { CardModule } from 'primeng/card';
import { RatingModule } from 'primeng/rating';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { PanelModule } from 'primeng/panel';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    UsuarioLoginComponent,
    UsuarioCadastroComponent,
  ],
  imports: [
    CommonModule,
    ButtonModule,
    InputTextModule,
    InputMaskModule,
    PerguntaRespostaModule,
    ReactiveFormsModule,
    MessagesModule,
    MessageModule,
    RouterModule,
    TableModule,
    AccordionModule, 
    CardModule ,
    RatingModule, 
    DialogModule ,
    DropdownModule, 
    PanelModule ,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: []
})
export class UsuarioModule { }
