import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Usuario } from './Usuario';



@Injectable({providedIn:'root'})
export class UsuarioService{
    
    constructor(private http:HttpClient){}

    listUser(){
        return this.http.get<Usuario[]>('http://localhost:52746/user/GetUser');
    }


    cadastrarUsuario(usuarioObj : Usuario):Observable<Usuario>{
        return this.http.post<Usuario>('http://localhost:52746/user/PostUser' , usuarioObj);
    }

    verificarAutenticacaoUsuario(ra:string , senha:string){
        const parametros = new HttpParams().set('ra' , ra).set('senha' , senha);
        return this.http.get<boolean>('http://localhost:52746/user/GeAuthenticationUser' , {params:parametros});
    }

}