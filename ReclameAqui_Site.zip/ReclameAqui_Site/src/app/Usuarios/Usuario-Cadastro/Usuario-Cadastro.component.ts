import { Component, Input, ViewEncapsulation } from '@angular/core';
import { MenuItem, SelectItem, MessageService } from 'primeng/api';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { UsuarioService } from '../Usuario.service';
import { Usuario } from '../Usuario';

@Component({
  selector: 'ra-cadastro',
  templateUrl: './Usuario-Cadastro.component.html',
  styleUrls: ['./Usuario-Cadastro.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class UsuarioCadastroComponent {
  userform: FormGroup;
  usuario: Usuario = {
    Nome: "",
    Email: "",
    CPF: "",
    RG: "",
    Indicador: 1,
    Senha: "",
    Id: 0
  };

  constructor(
    private usuarioService: UsuarioService,
    private fb: FormBuilder
  ) { }
  onNavigate() {
    window.location.href = "/Login/Entrar";
  }

  ngOnInit() {
    this.userform = this.fb.group({
      'tituloReclamacao': new FormControl('', Validators.required),
      'descricaoReclamacao': new FormControl('', Validators.required),
      'areaResponsavel': new FormControl('', Validators.required)
    });

  }

  cadastrarUsuario(NomeUsuario: string, EmailUsuario: string, RgUsuario: string, CpfUsuario: string, SenhaUsuario: string) {

    this.usuario.Nome = NomeUsuario;
    this.usuario.Email = EmailUsuario;
    this.usuario.Id = 0;
    this.usuario.Indicador = 1;
    this.usuario.RG = RgUsuario;
    this.usuario.CPF = CpfUsuario;
    this.usuario.Senha = SenhaUsuario;

    this.usuarioService.cadastrarUsuario(this.usuario).subscribe();
    window.location.href = "/Login/Entrar";

  }


  onSubmit() {
    // this.submitted = true;
    // let perguntaResposta = PerguntaResposta;
    // perguntaResposta.tituloReclamacao = this.userform.get('tituloReclamacao').value;
    // perguntaResposta.descPergRespo = this.userform.get('descricaoReclamacao').value;
    // perguntaResposta.codPergRespo = this.userform.get('areaResponsavel').value;

    // this.perguntaRespostaService.InserirPergunta(perguntaResposta).subscribe(
    //     retorno => {

    //     }
    // );

  }

}
