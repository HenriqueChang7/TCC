import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { UsuarioService } from '../Usuario.service';




@Component({
    selector: 'ra-login',
    templateUrl: 'Usuario-Login.component.html',
    styleUrls: ['Usuario-Login.component.css']
})
export class UsuarioLoginComponent implements OnInit {

    loginForm: FormGroup
    autentication: boolean = false;

    constructor(private formBuilder: FormBuilder,
        private usuarioService: UsuarioService,
        private router: Router) { }

    ngOnInit(): void {
        this.loginForm = this.formBuilder.group({
            raUser: ['', Validators.required],
            passwordUser: ['', Validators.required]
        });
    }


    Login() {
        const raUser = this.loginForm.get('raUser').value;
        const PasswordUser = this.loginForm.get('passwordUser').value;

        this.usuarioService.verificarAutenticacaoUsuario(raUser, PasswordUser).subscribe(auth => {
            if (auth) {
                this.router.navigate(['ReclameAqui/Index']);
            }
        });

       
    }

}


