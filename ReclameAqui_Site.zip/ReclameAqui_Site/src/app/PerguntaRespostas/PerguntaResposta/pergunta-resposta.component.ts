import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {MenuItem} from 'primeng/api'
import { PerguntaRespostaService } from '../pergunta-resposta.service';
import { PerguntaResposta } from '../pergunta-resposta';

@Component({
  selector: 'ra-pergunts-resposta',
  templateUrl: './pergunta-resposta.component.html',
  styleUrls: ['./pergunta-resposta.component.css'],
  encapsulation: ViewEncapsulation.None,
})

export class PerguntaRespostaComponent implements OnInit{

    listaReclamacoes : Array<PerguntaResposta>;
    cols: any[];
    val1: number = 3;
    display: boolean = false;
    listaRespostaReclamacao : Array<PerguntaResposta>;
    autoResize:boolean = true;
    constructor(private perguntaRespostaService : PerguntaRespostaService){ }

    ngOnInit() {
        this.listarReclamacao()
        this.cols = [
            { field: 'reclamacao', header: 'Reclamações:' },
        ];

    }

    listarReclamacao(){
        this.perguntaRespostaService.listReclamacoes().subscribe(listaReclamacao => {
            this.listaReclamacoes = listaReclamacao; 
        });

    }

    showDialog(listaReclamacao:any) {
        this.listaRespostaReclamacao = listaReclamacao;
        this.display = true;
    }

}
