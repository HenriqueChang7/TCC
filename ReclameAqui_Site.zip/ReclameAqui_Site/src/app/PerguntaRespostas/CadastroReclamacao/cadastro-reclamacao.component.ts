import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MenuItem, SelectItem, MessageService } from 'primeng/api'
import { PerguntaRespostaService } from '../pergunta-resposta.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AreaResponsavel } from '../AreaResponsavel';
import { PerguntaResposta } from '../pergunta-resposta';


@Component({
    selector: 'ra-cadastro-reclamacao',
    templateUrl: './cadastro-reclamacao.component.html',
    styleUrls: ['./cadastro-reclamacao.component.css'],
    encapsulation: ViewEncapsulation.None,
})

export class CadastroReclamacaoComponent implements OnInit {
    userform: FormGroup;
    submitted: boolean;
    genders: SelectItem[];
    description: string;
    areaResponsavelList: Array<AreaResponsavel>;
    perguntaResposta : PerguntaResposta = {
        tituloReclamacao:"",
        descArea : "",
        codPergRespo : 0,
        codArea : 0 ,
        codRelaPergRespo : 0,
        descPergRespo : "",
        indicPergResp :0 ,
        nomeUsuario : "",
        dataInclusao : new Date(),
        listaResposta: new Array<PerguntaResposta>()
    };
    
    constructor(
        private fb: FormBuilder,
        private perguntaRespostaService: PerguntaRespostaService
    ) { }

    ngOnInit() {
        this.userform = this.fb.group({
            'tituloReclamacao': new FormControl('', Validators.required),
            'descricaoReclamacao': new FormControl('', Validators.required),
            'areaResponsavel': new FormControl('', Validators.required)
        });

        this.listarAreaResponsavel()

    }

    onSubmit() {
        this.submitted = true;
        this.perguntaResposta.tituloReclamacao = this.userform.get('tituloReclamacao').value;
        this.perguntaResposta.descPergRespo = this.userform.get('descricaoReclamacao').value;
        this.perguntaResposta.codPergRespo = this.userform.get('areaResponsavel').value;

        this.perguntaRespostaService.InserirPergunta(this.perguntaResposta).subscribe(
            retorno => {

            }
        );

    }


    listarAreaResponsavel() {
        this.genders = [{ label: 'Selecione', value: '' }];

        this.perguntaRespostaService.listaAreaResponsavel().subscribe(retorno => {
            this.areaResponsavelList = retorno;
            this.areaResponsavelList.forEach(obj => {
                this.genders.push({ label: obj.DescricaoArea, value: obj.CodigoArea });
            });
        });


    }
}
