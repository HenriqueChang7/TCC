import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { PerguntaRespostaComponent } from './PerguntaResposta/pergunta-resposta.component';
import { MenuModule } from '../Menu/menu.module';
import {TableModule} from 'primeng/table';
import {AccordionModule} from 'primeng/accordion';
import {CardModule} from 'primeng/card';
import {RatingModule} from 'primeng/rating';
import {DialogModule} from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import { CadastroReclamacaoComponent } from './CadastroReclamacao/cadastro-reclamacao.component';
import { ReactiveFormsModule } from '@angular/forms';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {DropdownModule} from 'primeng/dropdown';
import {PanelModule} from 'primeng/panel';
import {HttpClientModule} from '@angular/common/http';

import {InputTextModule} from 'primeng/inputtext';
import {InputMaskModule} from 'primeng/inputmask';

@NgModule({
  declarations: [
    PerguntaRespostaComponent,
    CadastroReclamacaoComponent
  ],
  imports: [
    CommonModule,
    MenuModule,
    TableModule,
    AccordionModule,
    CardModule,
    RatingModule,
    DialogModule,
    BrowserAnimationsModule,
    ButtonModule,
    ReactiveFormsModule,
    MessageModule,
    MessagesModule,
    DropdownModule,
    PanelModule,
    HttpClientModule,
    InputMaskModule,
    InputTextModule,
    HttpModule

  ],
  providers: [],
  bootstrap: []
})
export class PerguntaRespostaModule {
    
 }
