
export interface PerguntaResposta {
    codPergRespo: number;
    descPergRespo: string;
    codRelaPergRespo: number;
    nomeUsuario: string;
    indicPergResp: number;
    descArea: string;
    codArea : number;
    listaResposta: Array<PerguntaResposta>;
    tituloReclamacao: string;
    dataInclusao: Date;
}