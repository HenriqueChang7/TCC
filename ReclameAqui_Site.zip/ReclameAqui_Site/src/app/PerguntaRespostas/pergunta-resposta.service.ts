import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PerguntaResposta } from './pergunta-resposta';
import { AreaResponsavel } from 'src/app/PerguntaRespostas/AreaResponsavel';


@Injectable({providedIn:'root'})
export class PerguntaRespostaService{
    
    constructor(private http:HttpClient){}

    listReclamacoes(){
        return this.http.get<Array<PerguntaResposta>>('http://localhost:52746/PerguntaResposta/GetPerguntaRespostaList');
    }

    listaAreaResponsavel(){
        return this.http.get<Array<AreaResponsavel>>('http://localhost:52746/PerguntaResposta/GetAreaResponsavel');
    }

    InserirPergunta(pergunta : PerguntaResposta){
        return this.http.post<PerguntaResposta>('http://localhost:52746/PerguntaResposta/PostPergunta' , pergunta)
    }
}