
export interface AreaResponsavel {
    CodigoArea: number;
    DescricaoArea: string;
}