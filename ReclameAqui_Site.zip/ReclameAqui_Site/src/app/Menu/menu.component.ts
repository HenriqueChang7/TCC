import { Component } from '@angular/core';
import {MenuItem} from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'ra-menu',
  templateUrl: './menu.component.html'
})

export class MenuComponent {

  items: MenuItem[];

  constructor(private router: Router){}

  ngOnInit() {
      this.items = [
          {
              label: 'Reclamações',
              icon: 'pi pi-angle-double-down',
              items: [
                  {
                    label: 'Nova Reclamação', 
                    icon: 'pi pi-fw pi-plus',
                    url: 'ReclameAqui/CadastroReclamacao'
                  },
                  {
                    label: 'Minhas Reclamações',
                    icon: 'pi pi-align-justify'
                  },
                  {
                    label: 'Todas as Reclamações',
                    icon: 'pi pi-users',
                    url:'ReclameAqui/Index'
                  },
                  {
                    label: 'Perfil',
                    icon: 'pi pi-user'
                  }
              ]
          }
      ];
  }

  Logout(){
    this.router.navigate([''])
  }
}
