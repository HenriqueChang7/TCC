import { NgModule } from '@angular/core';
import {Routes, RouterModule} from '@angular/router';


import { NotFoundComponent } from './errors/not-found/not-found.component';
import { UsuarioLoginComponent } from './Usuarios/Usuario-Login/Usuario-Login.component';
import { UsuarioCadastroComponent } from './Usuarios/Usuario-Cadastro/Usuario-Cadastro.component';
import { PerguntaRespostaComponent } from './PerguntaRespostas/PerguntaResposta/pergunta-resposta.component';
import { CadastroReclamacaoComponent } from './PerguntaRespostas/CadastroReclamacao/cadastro-reclamacao.component';


const routes:Routes= [
    {path: "", component:UsuarioLoginComponent},
    {path: "Cadastrar" , component:UsuarioCadastroComponent},
    {path: "ReclameAqui/Index" , component:PerguntaRespostaComponent},
    {path: "ReclameAqui/CadastroReclamacao" , component:CadastroReclamacaoComponent},
    
    {path: "**" , component:NotFoundComponent}
]
@NgModule({
    imports:[
        RouterModule.forRoot(routes),
    ],
    exports:[
        RouterModule
    ]
})   
export class AppRoutingModule{

}