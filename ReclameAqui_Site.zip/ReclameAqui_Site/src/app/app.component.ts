import { Component } from '@angular/core';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'ra-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  items: MenuItem[];

  ngOnInit() {
      this.items = [
          {
              label: 'Reclamações',
              icon: 'pi pi-angle-double-down',
              items: [
                  {
                    label: 'Nova Reclamação', 
                    icon: 'pi pi-fw pi-plus'
                  },
                  {
                    label: 'Minhas Reclamações',
                    icon: 'pi pi-align-justify'
                  },
                  {
                    label: 'Todas as Reclamações',
                    icon: 'pi pi-users'
                  },
                  {
                    label: 'Perfil',
                    icon: 'pi pi-user'
                  }
              ]
          }
      ];
  }
}
